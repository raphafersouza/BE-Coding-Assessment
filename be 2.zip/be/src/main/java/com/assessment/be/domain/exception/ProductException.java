package com.assessment.be.domain.exception;

public class ProductException extends RuntimeException {
    public ProductException(String s) {
        super(s);
    }
}