package com.assessment.be.adapter.model.request;

import java.time.LocalDate;

public class SubscriptionRequest {
    private Long productId;
    public Long getProductId() {
        return productId;
    }



}
