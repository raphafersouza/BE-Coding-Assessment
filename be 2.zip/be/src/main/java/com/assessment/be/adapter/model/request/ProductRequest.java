package com.assessment.be.adapter.model.request;

public class ProductRequest {
    private String name;
    public String getName() {
        return name;
    }

}
