package com.assessment.be.domain.exception;

public class SubscriptionStatusException extends RuntimeException {

    public SubscriptionStatusException(String s) {
        super(s);
    }
}
