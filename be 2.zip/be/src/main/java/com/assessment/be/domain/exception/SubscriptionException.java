package com.assessment.be.domain.exception;

public class SubscriptionException extends RuntimeException {

    public SubscriptionException(String s) {
        super(s);
    }
}
